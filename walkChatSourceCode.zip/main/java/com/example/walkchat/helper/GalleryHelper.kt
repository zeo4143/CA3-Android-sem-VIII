package com.example.walkchat.helper

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.walkchat.R
import com.example.walkchat.activities.PreviewStatus
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.Utils.showToast
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class GalleryHelper(private val requester: Any) {

    companion object {
        private const val PICK_MEDIA_REQUEST = 123
        private const val PERMISSION_REQUEST_CODE = 124
    }

    fun openGallery() {
        if (checkPermission()) {
            startGallery()
        } else {
            requestPermission()
        }
    }

    private fun checkPermission(): Boolean {
        val permission = Manifest.permission.WRITE_EXTERNAL_STORAGE
        return when (requester) {
            is Activity -> ContextCompat.checkSelfPermission(requester, permission) == PackageManager.PERMISSION_GRANTED
            is Fragment -> ContextCompat.checkSelfPermission(requester.requireContext(), permission) == PackageManager.PERMISSION_GRANTED
            else -> false
        }
    }

    private fun requestPermission() {
        when (requester) {
            is Activity -> ActivityCompat.requestPermissions(requester, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE)
            is Fragment -> requester.requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE)
        }
    }

    private fun startGallery() {
        val intent = Intent(Intent.ACTION_PICK).apply {
            type = "image/* video/*" // To select both images and videos
        }
        when (requester) {
            is Activity -> requester.startActivityForResult(intent, PICK_MEDIA_REQUEST)
            is Fragment -> requester.startActivityForResult(intent, PICK_MEDIA_REQUEST)
            else -> throw IllegalArgumentException("Requester must be either Activity or Fragment")
        }
    }

    fun handleActivityResult(requestCode: Int, resultCode: Int, data: Intent?): Uri? {
        return if (requestCode == PICK_MEDIA_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            data.data
        } else {
            null
        }
    }

    fun passMediaUriToNextActivity(activity: Activity, mediaUri: Uri) {
        val intent = Intent(activity, PreviewStatus::class.java).apply {
            putExtra(Constants.KEY_IMAGE, mediaUri.toString())
            putExtra(Constants.KEY_STATUS_MODE, Constants.KEY_MODE_UPLOAD)
        }
        activity.startActivity(intent)
    }

    suspend fun uploadMediaToCloudStorage(context: Context, mediaUri: Uri, userId: String) {
        val storage = FirebaseStorage.getInstance()
        val storageRef = storage.reference

        val filePath = "status/$userId/${System.currentTimeMillis()}"
        val mediaRef = storageRef.child(filePath)

        val inputStream: InputStream? = context.contentResolver.openInputStream(mediaUri)
        if (inputStream != null) {
            mediaRef.putStream(inputStream)
                .addOnSuccessListener {
                    showToast(requester as Activity, "status uploaded")
                }
                .addOnFailureListener {
                    showToast(requester as Activity, "failed to upload")
                }
        }
    }

    fun saveMediaToExternalStorage(context: Context, mediaUri: Uri, userId: String): Uri? {
        if (checkPermission()) {
            val inputStream: InputStream? = context.contentResolver.openInputStream(mediaUri)
            if (inputStream != null) {
                val outputFile = createMediaFile(context, userId)
                val outputStream = FileOutputStream(outputFile)
                inputStream.copyTo(outputStream)
                inputStream.close()
                outputStream.close()
                return Uri.fromFile(outputFile)
            }
        } else {
           showToast(requester as Activity, "failed to store image locally")
        }
        return null
    }

    private fun createMediaFile(context: Context, userId: String): File {
        val storageDir = context.getExternalFilesDir(null)
        val appDir = File(storageDir, context.getString(R.string.app_name))
        if (!appDir.exists()) {
            appDir.mkdirs()
        }
        val userDir = File(appDir, userId)
        if (!userDir.exists()) {
            userDir.mkdirs()
        }
        return File(userDir, "media_${System.currentTimeMillis()}.jpg")
    }
}
