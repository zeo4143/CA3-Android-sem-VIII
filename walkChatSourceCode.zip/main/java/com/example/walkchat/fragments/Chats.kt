package com.example.walkchat.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.walkchat.activities.Inbox
import com.example.walkchat.adapters.ConversationAdapter
import com.example.walkchat.databinding.FragmentChatsBinding
import com.example.walkchat.models.Contact
import com.example.walkchat.models.Conversation
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.google.firebase.Firebase
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.firestore
import java.text.SimpleDateFormat

class Chats : Fragment() {

    private var _binding: FragmentChatsBinding? = null
    private val binding get() = _binding!!

    private lateinit var preferenceManager: PreferenceManager
    private lateinit var conversationAdapter: ConversationAdapter
    private lateinit var conversations: MutableList<Conversation>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentChatsBinding.inflate(inflater, container, false)
        val view = binding.root
        init()
        listenConversations(preferenceManager.getString(Constants.KEY_USER_ID)!!)
        return view
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun init() {
        conversations = mutableListOf()
        preferenceManager = PreferenceManager(requireContext())
        conversationAdapter = ConversationAdapter(requireContext(), conversations)
        binding.conversationRecyclerView.adapter = conversationAdapter
    }

    private fun listenConversations(senderId: String) {
        Firebase.firestore.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
            .whereEqualTo(Constants.KEY_SENDER_ID, senderId)
            .addSnapshotListener(eventListener)

        Firebase.firestore.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
            .whereEqualTo(Constants.KEY_RECEIVER_ID, senderId)
            .addSnapshotListener(eventListener)
    }

    private  val eventListener = EventListener<QuerySnapshot> { value, error ->
        if(error != null) {
            return@EventListener
        } else if(value != null) {
            value.documentChanges.forEach {
                if(it.type == DocumentChange.Type.ADDED) {
                    conversations.add(
                        Conversation(
                            it.document.getString(Constants.KEY_SENDER_ID),
                            it.document.getString(Constants.KEY_RECEIVER_ID),
                            it.document.getString(Constants.KEY_RECENT_MESSAGE),
                            it.document.getString(Constants.KEY_TIMESTAMP)
                        )
                    )
                } else if(it.type == DocumentChange.Type.MODIFIED) {
                    for (i in 0..conversations.size) {
                        if(conversations[i].senderId?.equals(it.document.getString(Constants.KEY_SENDER_ID)) == true &&
                            conversations[i].receiverId?.equals(it.document.getString(Constants.KEY_RECEIVER_ID)) == true
                            ) {
                            conversations[i].recentMessage = it.document.getString(Constants.KEY_RECENT_MESSAGE)
                            conversations[i].messageTime = it.document.getString(Constants.KEY_TIMESTAMP)
                            break
                        }
                    }
                }
            }

            conversations.sortByDescending { it.messageTime?.let { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(it) } }
            conversationAdapter.notifyDataSetChanged()
            binding.conversationRecyclerView.smoothScrollToPosition(0)
            binding.conversationRecyclerView.visibility = View.VISIBLE
            binding.progressBar.visibility = View.GONE

        }
    }
}


