package com.example.walkchat.fragments

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.databinding.CustomEditTextDialogBinding
import com.example.walkchat.databinding.FragmentProfileBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.firebase.StorageRepo
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.FileNotFoundException

class Profile : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private lateinit var  fireStoreRepo: FireStoreRepo
    private lateinit var  storageRepo: StorageRepo
    private lateinit var  preferenceManager: PreferenceManager
    private var uri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val view = binding.root
        init()
        loadData()
        setListeners()
        return view
    }

    private fun init() {
        fireStoreRepo = FireStoreRepo(requireContext())
        storageRepo = StorageRepo()
        preferenceManager = PreferenceManager(requireContext())
    }

    private fun loadData() {
        Glide.with(this).load(preferenceManager.getString(Constants.KEY_IMAGE)).error(R.drawable.default_profile_img).into(binding.imageProfile)
        binding.textName.text = preferenceManager.getString(Constants.KEY_NAME)
        binding.textAbout.text = preferenceManager.getString(Constants.KEY_ABOUT)
        binding.textMoblieNumber.text = preferenceManager.getString(Constants.KEY_MOBILE_NO)
    }

    private fun setListeners() {
        binding.imageProfile.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            pickImage.launch(intent)
        }

        binding.textNameLayout.setOnClickListener {
            invokeDialogAndUpdate(Constants.KEY_NAME, "Update your Username", "Enter Name", binding.textName).apply {
                preferenceManager.putString(Constants.KEY_NAME, binding.textName.text.toString())
            }
        }

        binding.textAboutLayout.setOnClickListener {
            invokeDialogAndUpdate(Constants.KEY_ABOUT, "Change About", "Your about goes here", binding.textAbout).apply {
                preferenceManager.putString(Constants.KEY_ABOUT, binding.textAbout.text.toString())
            }
        }

        binding.checkHealthLayout.setOnClickListener {
            
        }
    }

    private val pickImage: ActivityResultLauncher<Intent> = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == AppCompatActivity.RESULT_OK) {
            if (it.data != null) {
                try {
                    if (it.data?.data != null) {
                        uri = it.data?.data!!

                        CoroutineScope(Dispatchers.Main).launch {
                            binding.progressBar.visibility = View.VISIBLE
                            storageRepo.uploadImage(uri!!).apply {
                                preferenceManager.putString(Constants.KEY_IMAGE, this)
                                Glide.with(this@Profile).load(this).into(binding.imageProfile)
                                binding.progressBar.visibility = View.GONE
                            }
                        }
                    }

                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun invokeDialogAndUpdate(key: String, title: String, hint: String, textView: TextView) {
        val dialogView = CustomEditTextDialogBinding.inflate(layoutInflater).root
        val dialog = android.app.AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val dialogTitle = dialogView.findViewById<TextView>(R.id.dialog_update_title)
        val editText = dialogView.findViewById<EditText>(R.id.dialog_edit_text_username)
        val progressBar = dialogView.findViewById<ProgressBar>(R.id.dialog_update_progress_bar)
        val btn = dialogView.findViewById<Button>(R.id.dialog_btn_update_username)


        fun updateUI(boolean: Boolean) {
            if(boolean) {
                progressBar.visibility = View.VISIBLE
                editText.visibility = View.GONE
                btn.isEnabled = false
            } else {
                progressBar.visibility = View.GONE
                editText.visibility = View.VISIBLE
                btn.isEnabled = true
            }
        }

        dialogTitle.text = title

        editText.setText(textView.text)
        editText.hint = hint
        editText.setOnFocusChangeListener { v, hasFocus ->
            if(hasFocus) v.background = resources.getDrawable(R.drawable.primary_background)
        }

        btn.setOnClickListener {
            if(editText.text.trim().isNotEmpty()) {
                updateUI(true)
                lifecycleScope.launch {
                    fireStoreRepo.updateUserByKey(key,editText.text.toString()).onSuccess {
                        textView.text = editText.text
                        preferenceManager.putString(key, editText.text.toString())
                        Toast.makeText(requireContext(), "updated successfully", Toast.LENGTH_SHORT).show()
                    }.onFailure {
                        Toast.makeText(requireContext(), "${it.message}", Toast.LENGTH_SHORT).show()
                    }.also {
                        updateUI(false)
                        dialog.dismiss()
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Enter $title", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}