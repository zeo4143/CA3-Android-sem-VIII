package com.example.walkchat.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.walkchat.activities.PreviewStatus
import com.example.walkchat.adapters.StatusAdapter
import com.example.walkchat.databinding.FragmentStatusBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.models.Status
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.objects.Utils.showToast
import com.example.walkchat.viewmodels.ContactViewModel
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat

class Status : Fragment() {

    private var _binding: FragmentStatusBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var fireStoreRepo: FireStoreRepo
    private lateinit var recentStatusAdapter: StatusAdapter
    private lateinit var recentStatus: MutableList<List<Status>>
    private lateinit var viewedStatus: MutableList<List<Status>>
    private lateinit var contactViewModel: ContactViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentStatusBinding.inflate(inflater, container, false)
        val view = binding.root
        init()
        setListeners()
        listenStatusUpdates()
        return view
    }

    private fun init() {
        preferenceManager = PreferenceManager(requireContext())
        fireStoreRepo = FireStoreRepo(requireContext())
        Glide.with(requireContext()).load(preferenceManager.getString(Constants.KEY_IMAGE)).into(binding.statusUserImg)
        contactViewModel = ViewModelProvider(requireContext() as FragmentActivity)[ContactViewModel::class.java]
        recentStatus = mutableListOf()
        viewedStatus = mutableListOf()
        recentStatusAdapter = StatusAdapter(requireContext(), recentStatus)
        binding.statusRecyclerView.adapter = recentStatusAdapter
    }

    private fun setListeners() {
        binding.addStatusLayout.setOnClickListener {
            startActivity(Intent( requireContext(), PreviewStatus::class.java).putExtra(Constants.KEY_STATUS_MODE, Constants.KEY_MODE_VIEW))
        }
    }

    private fun listenStatusUpdates() {
        contactViewModel.contacts.observe(requireActivity()) { contacts ->
            val filterContacts = contacts.filter { it.inDB }
            filterContacts.forEach { contact ->
                CoroutineScope(Dispatchers.IO).launch {
                    fireStoreRepo.listenStatusUpdates(
                        contact.contactId!!,
                        eventListener
                    )
                }
            }
        }
    }

    private val eventListener = EventListener<QuerySnapshot> {value, error ->
        if(error != null) {
            return@EventListener
        }

        val recentStatusUpdates = recentStatus.flatten().toMutableList()

        value?.documentChanges?.forEach {
            if (it.type == DocumentChange.Type.ADDED) {
                recentStatusUpdates.add(
                    Status(
                        it.document.getString(Constants.KEY_USER_ID),
                        it.document.getString(Constants.KEY_IMAGE),
                        it.document.getBoolean(Constants.KEY_IS_VIEWED),
                        it.document.getString(Constants.KEY_TIMESTAMP)
                    )
                )
            }
        }

        if(recentStatusUpdates.isNotEmpty()) {

           val groupStatusUpdates =  recentStatusUpdates.groupBy { it.userId }

            groupStatusUpdates.values.forEach { group ->
                group.sortedBy {
                    it.messageTime?.let { it1 ->
                        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(
                            it1
                        )
                    }
                }
            }

            val sortedGroups = groupStatusUpdates.values.sortedByDescending {
                it.last().messageTime?.let { it1 ->
                    SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(
                        it1
                    )
                }
            }

            recentStatus.clear()
            recentStatus.addAll(sortedGroups)
            showToast(requireContext(), "status are up-to-date")
            binding.statusRecyclerView.adapter?.notifyDataSetChanged()
            binding.statusRecyclerView.smoothScrollToPosition(0)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}