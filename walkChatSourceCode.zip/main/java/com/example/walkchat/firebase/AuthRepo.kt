package com.example.walkchat.firebase

import android.util.Log
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AuthRepo {

    private val firebaseAuth = FirebaseAuth.getInstance()

    private val callbacks = object: PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(p0: PhoneAuthCredential) {
            TODO("Not yet implemented")
        }

        override fun onVerificationFailed(p0: FirebaseException) {
            TODO("Not yet implemented")
        }

        override fun onCodeSent(p0: String, p1: PhoneAuthProvider.ForceResendingToken) {

        }

    }

    suspend fun creteUser(email: String, password: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val user = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            true
        } catch (e: Exception) {
            false
        }
    }



     fun getCurrentUser(): String {
         Log.d("currentUser", "getCurrentUser: ${firebaseAuth.currentUser?.uid.toString()}")
       return firebaseAuth.currentUser?.uid.toString()
    }

    suspend fun login(email: String, password: String):Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val isUserExists = firebaseAuth.signInWithEmailAndPassword(email,password).await()
            Pair(true, isUserExists.user?.uid.toString())
        } catch (e: FirebaseAuthException) {
            when(e) {
               is FirebaseAuthInvalidCredentialsException -> Pair(false, "Invalid Credentials")
                is FirebaseAuthInvalidUserException ->   Pair(false, "User not Found")
                else -> Pair(false, "something Went wrong")
            }
        }
    }
}