package com.example.walkchat.firebase

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.Firebase
import com.google.firebase.storage.storage

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class StorageRepo {

    private val storage = Firebase.storage

    suspend fun uploadImage(uri:Uri):String = withContext(Dispatchers.IO) {
        try {
            val fileName = FirebaseAuth.getInstance().uid.toString()
            val storageRef = storage.reference.child("profilePics/$fileName")
            storageRef.putFile(uri).await()
            return@withContext storageRef.downloadUrl.await().toString()
        } catch (e: Exception) {
            return@withContext ""
        }
    }

    suspend fun uploadStatus(uri:Uri):String = withContext(Dispatchers.IO) {
        try {
            val fileName = FirebaseAuth.getInstance().uid.toString()
            val storageRef = storage.reference.child("status/$fileName/${System.currentTimeMillis()}")
            storageRef.putFile(uri).await()
            return@withContext storageRef.downloadUrl.await().toString()
        } catch (e: Exception) {
            return@withContext ""
        }
    }
}