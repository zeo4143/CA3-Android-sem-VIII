package com.example.walkchat.firebase

import android.content.Context
import com.example.walkchat.models.ChatMessage
import com.example.walkchat.models.Contact
import com.example.walkchat.models.Status
import com.example.walkchat.models.User
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.google.firebase.Firebase
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.toObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FireStoreRepo(context: Context) {

    private val preferenceManager = PreferenceManager(context)
    private val db = Firebase.firestore
    private val users = db.collection(Constants.KEY_COLLECTION_USERS)
    private val chats = db.collection(Constants.KEY_COLLECTION_CHAT)
    private val status = db.collection(Constants.KEY_COLLECTION_STATUS)

    suspend fun createUser(user: User): String = withContext(Dispatchers.IO) {
        try {
           val userDocument = users.add(user).await()
            return@withContext userDocument.id
        } catch (e: Exception) {
            return@withContext ""
        }
    }



    suspend fun sendMessage(message: ChatMessage): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            chats.add(message).await()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }


    suspend fun getAllUsers(): Result<List<User>> = withContext(Dispatchers.IO) {
        try {
            Result.success(
            users
                .get()
                .await()
                .documents
                .mapNotNull { users ->
                    users.toObject<User>()
                }
                .filterNot {
                    it.userId == preferenceManager.getString(Constants.KEY_USER_ID)
                }
                .toList()
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUser(id: String): Result<Pair<String?, User?>> = withContext(Dispatchers.IO) {
        try {
            val userData = users.whereEqualTo(Constants.KEY_USER_ID ,id).get().await().documents.first()
            Result.success(Pair(userData.id,userData.toObject<User>()))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateUserByKey(key:String, value: Any):Result<Boolean> = withContext(Dispatchers.IO) {
       try {
           users.document(preferenceManager.getString(Constants.KEY_DATABASE_ID)!!).update(key, value)
           Result.success(true)
       } catch (e: Exception) {
           Result.failure(e)
       }
    }

    suspend fun deleteUserDataByKey(key: String): Boolean = withContext(Dispatchers.IO) {
        try {
            users.document(Constants.KEY_DATABASE_ID).update(key, FieldValue.delete())
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun uploadStatus(statusData: Status):Boolean = withContext(Dispatchers.Main) {
        try {
          status.add(statusData).await()
          true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun listenMessages(senderId: String, receiverId: String, snapshot: EventListener<QuerySnapshot>) = withContext(Dispatchers.Main) {
        try {
            chats
                .whereEqualTo(Constants.KEY_SENDER_ID, senderId)
                .whereEqualTo(Constants.KEY_RECEIVER_ID, receiverId)
                .addSnapshotListener(snapshot)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun listenStatusUpdates(contactId: String, snapshot: EventListener<QuerySnapshot>) = withContext(Dispatchers.IO) {
        try {
            status
                .whereEqualTo(Constants.KEY_USER_ID, contactId)
                .addSnapshotListener(snapshot)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

}