package com.example.walkchat.models

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0,
    var contactId: String? = null,
    var contactName: String? = null,
    var contactAbout: String? = null,
    var contactImage: String? =null,
    var fcmtoken: String? = null,
    val contactNo: String? = null,
    var inDB: Boolean = false,
    var steps: Long = 0
) : Parcelable{
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readByte() != 0.toByte(),
        parcel.readLong()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(contactId)
        parcel.writeString(contactName)
        parcel.writeString(contactAbout)
        parcel.writeString(contactImage)
        parcel.writeString(fcmtoken)
        parcel.writeString(contactNo)
        parcel.writeByte(if (inDB) 1 else 0)
        parcel.writeLong(steps)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Contact> {
        override fun createFromParcel(parcel: Parcel): Contact {
            return Contact(parcel)
        }

        override fun newArray(size: Int): Array<Contact?> {
            return arrayOfNulls(size)
        }
    }

}