package com.example.walkchat.models

import android.os.Parcel
import android.os.Parcelable
import java.util.ArrayList

data class ListOfStatus(
    val listOfStatus: ArrayList<Status>?
) : Parcelable {
    constructor(parcel: Parcel) : this(parcel.createTypedArrayList(Status)) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeTypedList(listOfStatus)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ListOfStatus> {
        override fun createFromParcel(parcel: Parcel): ListOfStatus {
            return ListOfStatus(parcel)
        }

        override fun newArray(size: Int): Array<ListOfStatus?> {
            return arrayOfNulls(size)
        }
    }

}
