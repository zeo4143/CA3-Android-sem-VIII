package com.example.walkchat.models

import android.os.Parcel
import android.os.Parcelable

data class User(
    val userId: String? = null,
    val name: String? =null,
    val about: String?=null,
    val mobileNo: String? = null,
    val fcmToken: String? = null,
    val image: String? = null,
    val availability: Int? = 0
) : Parcelable{
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Int::class.java.classLoader) as? Int
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(userId)
        parcel.writeString(name)
        parcel.writeString(about)
        parcel.writeString(mobileNo)
        parcel.writeString(fcmToken)
        parcel.writeString(image)
        parcel.writeValue(availability)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<User> {
        override fun createFromParcel(parcel: Parcel): User {
            return User(parcel)
        }

        override fun newArray(size: Int): Array<User?> {
            return arrayOfNulls(size)
        }
    }

}