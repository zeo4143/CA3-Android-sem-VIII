package com.example.walkchat.models

import android.os.Parcel
import android.os.Parcelable

data class Status(
    val userId: String? = null,
    val image: String? = null,
    var isViewed: Boolean? = false,
    var messageTime: String? = null
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readByte() != 0.toByte(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(userId)
        parcel.writeString(image)
        parcel.writeByte(if (isViewed == true) 1 else 0)
        parcel.writeString(messageTime)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Status> {
        override fun createFromParcel(parcel: Parcel): Status {
            return Status(parcel)
        }

        override fun newArray(size: Int): Array<Status?> {
            return arrayOfNulls(size)
        }
    }

}
