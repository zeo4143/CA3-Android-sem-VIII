package com.example.walkchat.interfaces

import com.example.walkchat.objects.Constants
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.HeaderMap
import retrofit2.http.Headers
import retrofit2.http.POST

interface ApiService {

    @Headers("${Constants.REMOTE_MSG_AUTHORIZATION}: key=${Constants.SERVER_KEY}, ${Constants.REMOTE_MSG_CONTENT_TYPE}: ${Constants.APPLICATION_TYPE}")
    @POST("fcm/send")
    fun sendMessage(
       @Body messageBody: String
    ): Call<String>
}