package com.example.walkchat.interfaces

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.walkchat.models.Contact

@Dao
interface ContactsDao {

    @Query("UPDATE contacts SET inDB = 'true' WHERE contactNo = :phoneNumber")
    suspend fun updateContactStatus(phoneNumber: String)

    @Transaction
    suspend fun updateContacts(contacts: List<Contact>) {
        Log.d("contactsDao", contacts.toString())
        contacts.forEach { contact ->
            updateContactDetails(contact.contactNo, contact.contactId, contact.contactImage, contact.contactAbout, contact.inDB)
        }
    }

    @Query("UPDATE contacts SET contactId = :contactId, contactImage = :contactImage, contactAbout = :contactAbout, inDB = :inDB  WHERE contactNo = :contactNo")
    suspend fun updateContactDetails(contactNo: String?, contactId: String?, contactImage: String?, contactAbout: String?, inDB: Boolean?)

    @Insert
    suspend fun insertContacts(contacts: List<Contact>)


    @Query("SELECT * FROM contacts")
    fun getAllContacts(): LiveData<List<Contact>>

    @Query("SELECT contactId FROM contacts")
    fun getAllContactIds(): LiveData<List<String>>


    @Query("SELECT * from contacts where contactId = :contactId")
    fun getContactById(contactId: String): LiveData<Contact>

}