package com.example.walkchat.objects

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.walkchat.interfaces.ContactsDao
import com.example.walkchat.models.Contact

class ContactRepository(private val contactsDao: ContactsDao) {

    fun contacts(): LiveData<List<Contact>> {
        return contactsDao.getAllContacts()
    }


    fun contact(contactId: String): LiveData<Contact> {
        return contactsDao.getContactById(contactId)

    }

    fun getAllContactIds(): LiveData<List<String>> {
        return contactsDao.getAllContactIds()
    }

    suspend fun insertContacts(contacts: List<Contact>) {
        contactsDao.insertContacts(contacts)
    }

    suspend fun updateContacts(contacts: List<Contact>) {
        Log.d("contactsRepo", contacts.toString())
        contactsDao.updateContacts(contacts)
    }

    suspend fun updateContactStatus(phoneNumber: String) {
        contactsDao.updateContactStatus(phoneNumber)
    }


}