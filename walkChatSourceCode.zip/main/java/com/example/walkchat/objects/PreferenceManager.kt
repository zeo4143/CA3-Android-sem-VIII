package com.example.walkchat.objects

import android.content.Context

class PreferenceManager(context: Context) {
    private val sharedPreferences =
        context.getSharedPreferences(Constants.KEY_COLLECTION_USERS, Context.MODE_PRIVATE)

    //Boolean Getters & Setters
    fun getBoolean(key: String):Boolean {
       return sharedPreferences.getBoolean(key, false)
    }

    fun putBoolean(key: String, value: Boolean) {
        sharedPreferences.edit().putBoolean(key,value).apply()
    }

    //String Getters & Setters
    fun getString(key: String): String? {
       return sharedPreferences.getString(key, null)
    }

    fun putString(key: String, value: String) {
        sharedPreferences.edit().putString(key,value).apply()
    }

    //clear sharedPreferences
    fun clear() {
        sharedPreferences.edit().clear().apply()
    }



}