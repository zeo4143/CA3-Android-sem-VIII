package com.example.walkchat.objects

object Constants {

    const val KEY_COLLECTION_USERS = "users"
    const val KEY_NAME = "name"
    const val KEY_ABOUT = "about"
    const val KEY_MOBILE_NO = "mobileNo"
    const val KEY_PREFERENCE_NAME = "chatApplicationPreference"
    const  val KEY_IS_SIGNED_IN = "isSignedIn"
    const val KEY_DATABASE_ID = "databaseId"
    const val KEY_USER_ID = "userId"
    const val KEY_CONVERSATION_ID = "conversationId"
    const val KEY_IMAGE = "image"
    const val KEY_FCM_TOKEN = "fcmToken"
    const val KEY_USER = "user"
    const val KEY_COLLECTION_CHAT = "chat"
    const val KEY_SENDER_ID = "senderId"
    const val KEY_RECEIVER_ID = "receiverId"
    const val KEY_MESSAGE = "message"
    const val KEY_TIMESTAMP = "messageTime"
    const val KEY_COLLECTION_CONVERSATIONS = "conversations"
    const val KEY_RECENT_MESSAGE = "recentMessage"
    const val KEY_AVAILABILITY = "availability"
    const val REMOTE_MSG_AUTHORIZATION = "Authorization"
    const val REMOTE_MSG_CONTENT_TYPE = "Content-Type"
    const val REMOTE_MSG_DATA = "data"
    const val REMOTE_MSG_REGISTRATION_IDS = "registration_ids"
    const val KEY_STATUS_MODE = "mode"
    const val KEY_MODE_UPLOAD = "upload"
    const val KEY_MODE_VIEW = "view"
    const val KEY_COLLECTION_STATUS = "status"
    const val KEY_IS_VIEWED = "isViewed"


    const val BASE_URL = "https://fcm.googleapis.com"
    const val SERVER_KEY = "AAAAsqc6Wcs:APA91bH4R7PQnFN2HQRdvu2Qo6ssvN9izfa1Fr0VPv8SohtEo8C3_O45F_ASZQrfJzF9hZrcGDxtJDiKqfLc9s6T1xhp_85nc3ezgDNI48RUgmAdZiB1Lq5Jyj7EeoygvXaTRPoyWC7Y"
    const val APPLICATION_TYPE = "application/json"


}