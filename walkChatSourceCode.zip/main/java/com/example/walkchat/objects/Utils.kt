package com.example.walkchat.objects

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.walkchat.models.Contact


object Utils {

    var remoteHeaders: HashMap<String, String>? = null

    fun showToast(context: Context, message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    fun changeActivity(context:Context ,activity: AppCompatActivity) {
        context.startActivity(Intent(context, activity::class.java))
    }


    fun fetchDeviceContacts(context: Context): MutableList<Contact> {

        val contacts = mutableListOf<Contact>()

        val contentResolver: ContentResolver = context.contentResolver
        val cursor = contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            null,
            null,
            null,
            null
        )

        cursor?.let {
            val idIndex = it.getColumnIndex(ContactsContract.Contacts._ID)
            val nameIndex = it.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)

            while (it.moveToNext()) {
                val id = it.getString(idIndex)
                val name = it.getString(nameIndex)

                val phoneCursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                    arrayOf(id),
                    null
                )

                phoneCursor?.let { phoneCur ->
                    val phoneNumberIndex = phoneCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (phoneCur.moveToNext()) {
                        var phoneNumber = phoneCur.getString(phoneNumberIndex)
                        phoneNumber = phoneNumber.replace("\\s".toRegex(), "")
                        if (!phoneNumber.startsWith("+91")) {
                            phoneNumber = "+91$phoneNumber"
                        }
                        if (phoneNumber.length <= 13) {
                            contacts.add(Contact(contactName = name, contactNo =  phoneNumber))
                        } else {
                            Log.d("Invalid NUmber", "Invalid phone number: $phoneNumber")
                        }
                    }

                    phoneCur.close()
                }

            }

            it.close()
        }

        return contacts.distinctBy {
            it.contactNo
        }.toMutableList()
    }



}