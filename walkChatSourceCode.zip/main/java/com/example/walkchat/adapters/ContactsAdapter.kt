package com.example.walkchat.adapters

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.activities.Inbox
import com.example.walkchat.databinding.ItemContainerUserBinding
import com.example.walkchat.models.Contact
import com.example.walkchat.objects.Constants

class ContactsAdapter(
    private val context: Activity,
    private val contacts: List<Contact>
): RecyclerView.Adapter<ContactsAdapter.ViewHolder>() {

    inner class ViewHolder(view:View): RecyclerView.ViewHolder(view) {
        val binding:ItemContainerUserBinding = ItemContainerUserBinding.bind(view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactsAdapter.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_container_user, parent, false))
    }

    override fun onBindViewHolder(holder: ContactsAdapter.ViewHolder, position: Int) {
        val i = contacts[position]

        holder.binding.textName.text = i.contactName
        Glide.with(context).load(i.contactImage).error(R.drawable.default_profile_img).into(holder.binding.imageProfile)
        
        if(i.inDB) {
            holder.binding.textAbout.text = i.contactAbout
        } else {
            holder.binding.textAbout.text = context.getString(R.string.click_to_invite_them)
        }

        holder.itemView.setOnClickListener {
            if (i.inDB) {
                context.startActivity(Intent(context, Inbox::class.java).putExtra(Constants.KEY_USER, i))
                context.finish()
            } else {
                inviteFriend("", i.contactNo!!)
            }
        }
        
    }


    override fun getItemCount(): Int {
        return contacts.size
    }

    private fun inviteFriend(message: String, number: String) {
        val uri = Uri.parse("smsto:$number")
        val intent = Intent(Intent.ACTION_SENDTO, uri)
        intent.putExtra("sms_body", message)
        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        }
    }
}