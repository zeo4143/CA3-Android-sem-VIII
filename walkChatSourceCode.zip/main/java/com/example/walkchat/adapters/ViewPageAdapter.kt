package com.example.walkchat.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.walkchat.fragments.Status
import com.example.walkchat.fragments.Chats
import com.example.walkchat.fragments.Profile


class ViewPageAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle): FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int = 3

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> Chats()
            1 -> Status()
            2 -> Profile()

            // Add more cases if needed
            else -> Chats()
        }
    }
}