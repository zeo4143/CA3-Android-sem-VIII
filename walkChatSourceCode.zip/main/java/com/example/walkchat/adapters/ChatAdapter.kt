package com.example.walkchat.adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.databinding.ItemContainerReceiveMessageBinding
import com.example.walkchat.databinding.ItemContainerSendMessageBinding
import com.example.walkchat.models.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatAdapter(
    private val context: Context,
    private val chatMessages: List<ChatMessage>,
    private val senderId: String,
    private val receiverImage: String?
): RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_SENT = 1
        private const val VIEW_TYPE_RECEIVE = 2
    }

    inner class SentMessageViewHolder(view: View): RecyclerView.ViewHolder(view) {
        private val sender: ItemContainerSendMessageBinding = ItemContainerSendMessageBinding.bind(view)

        fun setData(message: ChatMessage) {
            sender.textMessage.text = message.message
            sender.textDateTime.text = formatDate(message.messageTime)
        }

    }

    inner class ReceiveMessageViewHolder(view: View): RecyclerView.ViewHolder(view) {
        private val receiver: ItemContainerReceiveMessageBinding = ItemContainerReceiveMessageBinding.bind(view)

        fun setData(message: ChatMessage) {
            receiver.textMessage.text = message.message
            receiver.textDateTime.text = formatDate(message.messageTime)
            Glide.with(context).load(receiverImage).placeholder(R.drawable.default_profile_img).into(receiver.imageProfile)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if(viewType == VIEW_TYPE_SENT) {
            SentMessageViewHolder(LayoutInflater.from(context).inflate(R.layout.item_container_send_message, parent, false))
        } else {
            ReceiveMessageViewHolder(LayoutInflater.from(context).inflate(R.layout.item_container_receive_message, parent, false))
        }
    }

    override fun getItemCount(): Int {
       return chatMessages.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = chatMessages[position]
        if(getItemViewType(position) == VIEW_TYPE_SENT) {
            Log.d("ChatAdapter", "called send")
            SentMessageViewHolder(holder.itemView).setData(message)
        } else {
            Log.d("ChatAdapter", "called receive")
            ReceiveMessageViewHolder(holder.itemView).setData(message)
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if(chatMessages[position].senderId.equals(senderId)) {
            Log.d("chatAdapter", chatMessages[position].senderId.toString())
            VIEW_TYPE_SENT
        } else {
            VIEW_TYPE_RECEIVE
        }
    }

    private fun formatDate(inputDateString: String?): String {
        // Parse the input date string
        val inputFormat = SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'", Locale.getDefault())
        val date: Date = inputFormat.parse(inputDateString) ?: return ""

        // Format the date to the desired format
        val outputFormat = SimpleDateFormat("MMMM dd, yyyy - HH:mm", Locale.getDefault())
        return outputFormat.format(date)
    }


}