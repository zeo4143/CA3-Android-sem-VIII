package com.example.walkchat.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.activities.PreviewStatus
import com.example.walkchat.databinding.ItemContainerStatusBinding
import com.example.walkchat.models.ListOfStatus
import com.example.walkchat.models.Status
import com.example.walkchat.objects.Constants
import com.example.walkchat.viewmodels.ContactViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StatusAdapter(
    private val context: Context,
    private val status: MutableList<List<Status>>
): RecyclerView.Adapter<StatusAdapter.ViewHolder>() {

    private lateinit var contactViewModel: ContactViewModel

    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val binding: ItemContainerStatusBinding = ItemContainerStatusBinding.bind(view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_container_status,parent,false))
    }

    override fun getItemCount(): Int {
        return status.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val i = status[position]

        contactViewModel = ViewModelProvider(context as FragmentActivity)[ContactViewModel::class.java]

        contactViewModel.contactById(i.first().userId!!).observe(context){
            Glide.with(context).load(it.contactImage).error(R.drawable.default_profile_img).into(holder.binding.imageProfile)
            holder.binding.textName.text = it.contactName
            holder.binding.textRecentUploadTime.text = formatDate(i.last().messageTime)
        }

        if(i.any { it.isViewed == false }) {
            val padding = com.intuit.sdp.R.dimen._1sdp
            holder.binding.imageProfile.setPadding(padding,padding,padding,padding)
        } else {
            holder.binding.imageProfile.setPadding(0,0,0,0)
        }

//        holder.itemView.setOnClickListener {
//            context.startActivity(
//                Intent(context, PreviewStatus::class.java)
//                    .putExtra(Constants.KEY_STATUS_MODE, Constants.KEY_MODE_VIEW)
//                    .putExtra<ListOfStatus>(Constants.KEY_COLLECTION_STATUS, i)
//            )
//        }


    }

    private fun formatDate(inputDateString: String?): String {
        // Parse the input date string
        val inputFormat = SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'", Locale.getDefault())
        val date: Date = inputFormat.parse(inputDateString) ?: return ""

        // Format the date to the desired format
        val outputFormat = SimpleDateFormat("MMMM dd, yyyy - HH:mm", Locale.getDefault())
        return outputFormat.format(date)
    }

}