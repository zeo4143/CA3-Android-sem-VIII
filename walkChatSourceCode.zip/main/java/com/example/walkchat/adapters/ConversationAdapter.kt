package com.example.walkchat.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.activities.Inbox
import com.example.walkchat.databinding.ItemContainerRecentConversationBinding
import com.example.walkchat.models.Contact
import com.example.walkchat.models.Conversation
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.viewmodels.ContactViewModel

class ConversationAdapter(
    private val context: Context,
    private val conversations: MutableList<Conversation>,
): RecyclerView.Adapter<ConversationAdapter.ViewHolder>() {

    private lateinit var contactViewModel: ContactViewModel
    private val preferenceManager = PreferenceManager(context)

    inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val binding: ItemContainerRecentConversationBinding = ItemContainerRecentConversationBinding.bind(view)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConversationAdapter.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_container_recent_conversation, parent, false))
    }

    override fun getItemCount(): Int {
        return conversations.size
    }

    override fun onBindViewHolder(holder: ConversationAdapter.ViewHolder, position: Int) {
       val i = conversations[position]

        contactViewModel = ViewModelProvider(context as FragmentActivity)[ContactViewModel::class.java]

        contactViewModel.contactById(getConnectionId(i)).observe(context) { receiverDetail ->
            holder.binding.textName.text = receiverDetail?.contactName
            Glide.with(context).load(receiverDetail?.contactImage).error(R.drawable.default_profile_img).into(holder.binding.imageProfile)

            holder.itemView.setOnClickListener {
                context.startActivity(Intent(context, Inbox::class.java).putExtra(Constants.KEY_USER, receiverDetail))
                context.overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
            }
        }

        holder.binding.textRecentMessage.text = i.recentMessage

    }

    private fun getConnectionId(contact: Conversation): String {
        return if(contact.senderId.equals(preferenceManager.getString(Constants.KEY_USER_ID))) {
            contact.receiverId!!
        } else {
            contact.senderId!!
        }
    }
}