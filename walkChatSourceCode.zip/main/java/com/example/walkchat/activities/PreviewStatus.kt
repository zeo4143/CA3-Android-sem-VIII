package com.example.walkchat.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.bumptech.glide.Glide.init
import com.example.walkchat.R
import com.example.walkchat.databinding.ActivityPreviewStatusBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.firebase.StorageRepo
import com.example.walkchat.helper.GalleryHelper
import com.example.walkchat.models.Status
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.objects.Utils.showToast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PreviewStatus : BaseActivity() {

    private lateinit var binding: ActivityPreviewStatusBinding
    private lateinit var galleryHelper: GalleryHelper
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var storageRepo: StorageRepo
    private lateinit var fireStoreRepo: FireStoreRepo
    private lateinit var uri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
        setListeners()
    }

    private fun init() {
        val intent = intent.getStringExtra(Constants.KEY_STATUS_MODE)
        fireStoreRepo = FireStoreRepo(this)
        storageRepo = StorageRepo()
        if(intent == Constants.KEY_MODE_UPLOAD) {
            binding.statusAdapter.visibility = View.GONE
            binding.layoutSend.visibility = View.VISIBLE
            binding.inputMessage.visibility = View.VISIBLE
            binding.imageBack.visibility = View.VISIBLE
            loadImage()
        } else {
            binding.statusAdapter.visibility = View.VISIBLE
            binding.layoutSend.visibility = View.GONE
            binding.inputMessage.visibility = View.GONE
            binding.imageBack.visibility = View.GONE
        }
        preferenceManager = PreferenceManager(this)
        galleryHelper = GalleryHelper(this)
    }

    private fun loadImage() {
        uri = Uri.parse(intent.getStringExtra(Constants.KEY_IMAGE))
        Glide.with(this).load(uri).into(binding.imageStatus)
    }

    private fun setListeners() {
        binding.layoutSend.setOnClickListener {
            uploadStatus()
        }

        binding.imageBack.setOnClickListener {
            onBackPressed()
        }
    }


    private fun uploadStatus() {
        CoroutineScope(Dispatchers.Main).launch {
            isLoading(true)
            val url = async { storageRepo.uploadStatus(uri) }.await()

            if(url.isNotEmpty()) {
               fireStoreRepo.uploadStatus(
                   Status(
                       preferenceManager.getString(Constants.KEY_USER_ID),
                       url,
                       false,
                       SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'").format(Date())
                   )
               ).apply {
                   if(this) {
                       showToast(this@PreviewStatus, "status uploaded")
                   } else {
                       showToast(this@PreviewStatus, "something went wrong")
                   }

                   isLoading(false)
                   finish()
               }
            } else {
                showToast(this@PreviewStatus, "fail to upload image")
                isLoading(false)
                finish()
            }
        }

    }

    private fun isLoading(boolean: Boolean){
        if (boolean) {
            binding.previewStatusProgressBar.visibility = View.VISIBLE
            binding.layoutSend.isEnabled = false
            binding.inputMessage.isEnabled = false
            binding.imageBack.isEnabled = false
        } else {
            binding.previewStatusProgressBar.visibility = View.GONE
            binding.layoutSend.isEnabled = true
            binding.inputMessage.isEnabled = true
            binding.imageBack.isEnabled = true
        }
    }

}