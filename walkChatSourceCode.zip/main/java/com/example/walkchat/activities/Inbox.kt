package com.example.walkchat.activities

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.core.view.marginLeft
import androidx.databinding.adapters.TextViewBindingAdapter.setText
import com.example.walkchat.R
import com.example.walkchat.adapters.ChatAdapter
import com.example.walkchat.databinding.ActivityInboxBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.interfaces.ApiService
import com.example.walkchat.models.ChatMessage
import com.example.walkchat.models.Contact
import com.example.walkchat.models.Conversation
import com.example.walkchat.objects.ApiClient
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.objects.Utils
import com.example.walkchat.objects.Utils.showToast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.Firebase
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Inbox : BaseActivity() {
    private lateinit var binding: ActivityInboxBinding
    private lateinit var receiverUser: Contact
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var fireStoreRepo: FireStoreRepo
    private lateinit var chatMessages: MutableList<ChatMessage>
    private lateinit var chatAdapter: ChatAdapter

    private val REQUEST_CODE_SPEECH_INPUT = 10001

    private var isReceiverAvailable: Boolean = false

    private var conversationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInboxBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setListeners()
        loadReceiverDetails()
        init()
        listenMessages()

        Log.d("chatMessages", preferenceManager.getString(Constants.KEY_USER_ID).toString())
        Log.d("chatMessages", receiverUser.contactId.toString())
    }

    override fun onResume() {
        super.onResume()
        listenAvailabilityOfReceiver()
    }


    private fun init() {
        preferenceManager = PreferenceManager(this)
        fireStoreRepo = FireStoreRepo(this)
        chatMessages = mutableListOf()
        chatAdapter = ChatAdapter(
            this,
            chatMessages,
            preferenceManager.getString(Constants.KEY_USER_ID)!!,
            receiverUser.contactImage
        )
        binding.chatRecyclerView.adapter = chatAdapter

        binding.inputMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                val layoutParams = binding.sendMessageIcon.layoutParams as ViewGroup.MarginLayoutParams

                if(binding.inputMessage.text.isNotEmpty()) {
                    binding.sendMessageIcon.setImageResource(R.drawable.outline_send_24)
                    layoutParams.leftMargin = resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._4sdp)

                } else {
                    binding.sendMessageIcon.setImageResource(R.drawable.baseline_mic_24)
                    layoutParams.leftMargin = 0
                }

                binding.sendMessageIcon.layoutParams = layoutParams

            }
        })
    }

    private fun loadReceiverDetails() {
        receiverUser = intent.getParcelableExtra(Constants.KEY_USER)!!
        binding.textName.text = receiverUser.contactName
    }

    private fun setListeners() {

        binding.imageBack.setOnClickListener {
            onBackPressed()
        }

        binding.layoutSend.setOnClickListener {
            if(binding.inputMessage.text.trim().isNotEmpty()) {
                sendMessage( binding.inputMessage.text.trim().toString())
            } else {
                startVoiceInput()
            }
        }
    }

    private fun sendNotification(messageBody: String) {

        ApiClient.getClient()?.create(ApiService::class.java)?.sendMessage(messageBody)?.enqueue(object : Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                if (response.isSuccessful) {
                    try {
                        val responseJSON = JSONObject(response.body() ?: "")
                        val failureCount = responseJSON.optInt("failure", 0)
                        if (failureCount == 1) {
                            val results = responseJSON.optJSONArray("results")
                            val error = results?.optJSONObject(0)?.optString("error")
                            showToast(this@Inbox, error ?: "Unknown error")
                            Log.d("NotificationManager2", error.toString())
                            return
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }

                    showToast(this@Inbox, "Notification Sent Successfully")

                } else {
                    Log.d("NotificationManager3", response.toString())
                    showToast(this@Inbox,"Error: " + response.code())
                }
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                // Handle failure
                Log.d("NotificationManager4", t.message.toString())
                showToast(this@Inbox, "Failed to send message: ${t.message}")
            }
        })


    }

    private fun listenAvailabilityOfReceiver() {
        CoroutineScope(Dispatchers.Main).launch {
            fireStoreRepo.getUser(receiverUser.contactId!!).onSuccess {
                if(it.second != null) {
                    isReceiverAvailable = it.second!!.availability == 1
                    receiverUser.fcmtoken = it.second!!.fcmToken
                }

                if(isReceiverAvailable) {
                    binding.textAvailability.visibility = View.VISIBLE
                }
                else {
                    binding.textAvailability.visibility = View.GONE
                }
            }
        }

    }

    private fun listenMessages() {
        CoroutineScope(Dispatchers.Main).launch {
            fireStoreRepo.listenMessages(
                preferenceManager.getString(Constants.KEY_USER_ID)!!,
                receiverUser.contactId.toString(),
                eventListener
                )
            fireStoreRepo.listenMessages(
                receiverUser.contactId.toString(),
                preferenceManager.getString(Constants.KEY_USER_ID)!!,
                eventListener
            )
        }
    }

    private val eventListener: EventListener<QuerySnapshot> = EventListener<QuerySnapshot> { snapShot, error ->
        if(error != null) {
            return@EventListener
        }

        if(snapShot != null) {
            val count = chatMessages.size
            snapShot.documentChanges.forEach {
                if(it.type == DocumentChange.Type.ADDED) {
                    chatMessages.add(
                        ChatMessage(
                            it.document.getString(Constants.KEY_SENDER_ID),
                            it.document.getString(Constants.KEY_RECEIVER_ID),
                            it.document.getString(Constants.KEY_MESSAGE),
                            it.document.getString(Constants.KEY_TIMESTAMP)
                        )
                    )
                }
            }


            chatMessages.sortBy { it.messageTime?.let { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(it) } }

            if(count == 0) {
                chatAdapter.notifyDataSetChanged()
            } else {
                chatAdapter.notifyItemRangeInserted(chatMessages.size, chatMessages.size)
                binding.chatRecyclerView.smoothScrollToPosition(chatMessages.size - 1)
            }

            Log.d("chatMessages",chatMessages.toString())

            binding.chatRecyclerView.visibility = View.VISIBLE
            binding.progressBar.visibility = View.GONE

            if(conversationId == null) {
                checkConversations()
            }
        }
    }

    private val conversationOnCompletedListener: OnCompleteListener<QuerySnapshot> = OnCompleteListener { task ->
        if(task.isSuccessful && task.result != null && task.result.documents.size > 0 ) {
            conversationId = task.result.documents.first().id
        }
    }

    private fun sendMessage(message: String) {
        CoroutineScope(Dispatchers.Main).launch {
            fireStoreRepo.sendMessage(
                ChatMessage(
                    preferenceManager.getString(Constants.KEY_USER_ID),
                    receiverUser.contactId,
                    message,
                    SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'").format(Date())
                )
            ).onSuccess {
                if(conversationId != null) {
                    updateConversations(binding.inputMessage.text.trim().toString())
                } else {
                    addConversation(
                        Conversation(
                            preferenceManager.getString(Constants.KEY_USER_ID),
                            receiverUser.contactId,
                            message,
                            SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'").format(Date())
                        )
                    )
                }

                binding.inputMessage.text.clear()

                if (!isReceiverAvailable) {
                    try {
                        val data = JSONObject().apply {
                            put(Constants.KEY_USER_ID, preferenceManager.getString(Constants.KEY_USER_ID))
                            put(Constants.KEY_NAME, preferenceManager.getString(Constants.KEY_NAME))
                            put(Constants.KEY_FCM_TOKEN, preferenceManager.getString(Constants.KEY_FCM_TOKEN))
                            put(Constants.KEY_MESSAGE, binding.inputMessage.text.trim().toString())
                        }

                        val body = JSONObject().apply {
                            put(Constants.REMOTE_MSG_DATA, data)
                            put(Constants.REMOTE_MSG_REGISTRATION_IDS, receiverUser.fcmtoken)
                        }

                        sendNotification(body.toString())

                    } catch (e: Exception) {
                        Log.d("NotificationManager1", e.message.toString() )
                        showToast(this@Inbox, e.message.toString())
                    }
                }

            }.onFailure {
                showToast(this@Inbox, "Unable to send message")
            }
        }
    }

    private fun addConversation(conversation: Conversation) {
        Firebase.firestore.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
            .add(conversation)
            .addOnSuccessListener {
                conversationId = it.id
            }
    }

    private fun updateConversations(message: String) {
        Firebase.firestore.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
            .document(conversationId!!)
            .update(
                Constants.KEY_RECENT_MESSAGE, message,
                Constants.KEY_TIMESTAMP, SimpleDateFormat("dd-MM-yyyy'T'HH:mm:ss'Z'").format(Date())
            )
    }

    private fun checkConversations() {
        if(chatMessages.size != 0) {
            checkConversationRemotely(
                preferenceManager.getString(Constants.KEY_USER_ID)!!,
                receiverUser.contactId!!
            )

            checkConversationRemotely(
                receiverUser.contactId!!,
                preferenceManager.getString(Constants.KEY_USER_ID)!!
            )
        }
    }

    private fun checkConversationRemotely(senderId: String, receiverId: String) {
        Firebase.firestore.collection(Constants.KEY_COLLECTION_CONVERSATIONS)
            .whereEqualTo(Constants.KEY_SENDER_ID, senderId)
            .whereEqualTo(Constants.KEY_RECEIVER_ID, receiverId)
            .get()
            .addOnCompleteListener(conversationOnCompletedListener)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE,
            Locale.getDefault()
        )
        intent.putExtra(
            RecognizerIntent.EXTRA_PROMPT,
            "Speak something..."
        )
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: ActivityNotFoundException) {
            Log.e("Error", e.message!!)
        }
    }

    override fun startActivity(intent: Intent?) {
        super.startActivity(intent)
        overridePendingTransition(R.anim.fade_out, R.anim.fade_in)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_SPEECH_INPUT -> {
                if (resultCode == -1 && data != null) {
                    val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    val spokenText = result?.get(0)
                    if (spokenText != null) {
                        binding.inputMessage.setText(spokenText)
                        sendMessage(spokenText)
                    }
                }
            }
        }
    }


}