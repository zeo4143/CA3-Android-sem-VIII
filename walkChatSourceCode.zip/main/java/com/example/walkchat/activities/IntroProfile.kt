package com.example.walkchat.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.databinding.ActivityIntroProfileBinding
import com.example.walkchat.databinding.CustomEditTextDialogBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.firebase.StorageRepo
import com.example.walkchat.models.User
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.objects.Utils.changeActivity
import com.example.walkchat.objects.Utils.showToast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.io.FileNotFoundException

class IntroProfile : AppCompatActivity() {

    private lateinit var binding: ActivityIntroProfileBinding
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var fireStoreRepo: FireStoreRepo
    private lateinit var storageRepo: StorageRepo

    private var mobileNo: String? = null
    private var uri:Uri? = null
    private var imageUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIntroProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
        checkExistingUserOrNot()
        setListeners()
    }

    private fun init() {
        preferenceManager = PreferenceManager(this)
        fireStoreRepo = FireStoreRepo(this)
        storageRepo = StorageRepo()
    }

    private fun setListeners() {
        binding.imageProfile.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            pickImage.launch(intent)
        }
        binding.btnNext.setOnClickListener {
            if(allChecksDone()) {
                saveData()
            }
        }

        binding.textNameLayout.setOnClickListener {
            invokeDialogAndOverwrite("Enter Name", "Enter your Name", binding.textName)
        }

        binding.textAboutLayout.setOnClickListener {
            invokeDialogAndOverwrite("About", "Enter your about", binding.textAbout)
        }
    }

    private fun loadDetails() {
        mobileNo = intent.getStringExtra(Constants.KEY_MOBILE_NO)
        binding.textMoblieNumber.text = mobileNo
    }

    private fun checkExistingUserOrNot() {
        isLoading(true)
        CoroutineScope(Dispatchers.Main).launch {
            fireStoreRepo.getUser(FirebaseAuth.getInstance().currentUser?.uid.toString()).onSuccess {
                if(it.first != null) {
                    preferenceManager.putString(Constants.KEY_DATABASE_ID, it.first!!)
                    binding.textName.text = it.second?.name
                    binding.textAbout.text = it.second?.about
                    binding.textMoblieNumber.text = it.second?.mobileNo
                    Glide.with(this@IntroProfile).load(it.second?.image).error(R.drawable.default_profile_img).into(binding.imageProfile)
                    isLoading(false)
                } else {
                    loadDetails()
                    isLoading(false)
                }
            }.onFailure {
                loadDetails()
                isLoading(false)
            }
        }
    }

    private val pickImage: ActivityResultLauncher<Intent> = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            if (it.data != null) {
                try {
                    if (it.data?.data != null) {
                        uri = it.data?.data!!
                        Glide.with(this).load(uri).into(binding.imageProfile)
                        binding.textAddImage.visibility = View.GONE
                    }

                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
            }
        }
    }

    private suspend fun createUser(user: User) {
            fireStoreRepo.createUser(user).apply {
                preferenceManager.putString(Constants.KEY_DATABASE_ID, this).apply {
                    updatePreferences()
                }
            }

    }

    private fun saveData() {
        isLoading(true)
        CoroutineScope(Dispatchers.Main).launch {
            imageUrl = async {   uri?.let { storageRepo.uploadImage(it) } }.await()

            if(preferenceManager.getString(Constants.KEY_DATABASE_ID) != null) {

               async { fireStoreRepo.updateUserByKey(Constants.KEY_NAME, binding.textName.text.trim().toString())}.await()
               async { fireStoreRepo.updateUserByKey(Constants.KEY_ABOUT, binding.textAbout.text.trim().toString())}.await()
               async { imageUrl?.let { fireStoreRepo.updateUserByKey(Constants.KEY_IMAGE, it) }}.await()
                updatePreferences()

            } else {

                createUser(
                    User(
                        FirebaseAuth.getInstance().currentUser?.uid.toString(),
                        binding.textName.text.trim().toString(),
                        binding.textAbout.text.trim().toString(),
                        mobileNo,
                        imageUrl
                    )
                )
            }
        }
    }


    private fun updatePreferences() {
        preferenceManager.putString(Constants.KEY_USER_ID, FirebaseAuth.getInstance().currentUser?.uid.toString())
        preferenceManager.putString(Constants.KEY_NAME, binding.textName.text.trim().toString())
        preferenceManager.putString(Constants.KEY_ABOUT, binding.textAbout.text.trim().toString())
        preferenceManager.putString(Constants.KEY_MOBILE_NO, binding.textMoblieNumber.text.toString())
        imageUrl?.let { preferenceManager.putString(Constants.KEY_IMAGE, it) }
        isLoading(false)
        changeActivity(this@IntroProfile, MainActivity())
        finish()
    }

    private fun allChecksDone(): Boolean {
        return if(binding.textName.text.trim().toString().isEmpty()) {
            showToast(this, "Enter Name")
            false
        } else {
            true
        }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("UseCompatLoadingForDrawables")
    private fun invokeDialogAndOverwrite(title: String, hint: String, textView: TextView) {
        val dialogView = CustomEditTextDialogBinding.inflate(layoutInflater).root
        val dialog = android.app.AlertDialog.Builder(this@IntroProfile)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))


        val editText = dialogView.findViewById<EditText>(R.id.dialog_edit_text_username)
        val btn = dialogView.findViewById<Button>(R.id.dialog_btn_update_username)


        editText.setText(textView.text)
        editText.hint = hint
        editText.setOnFocusChangeListener { v, hasFocus ->
            if(hasFocus) v.background = resources.getDrawable(R.drawable.primary_background)
        }

        btn.setOnClickListener {
            if(editText.text.trim().isNotEmpty()) {
                textView.text = editText.text
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Enter $title", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun isLoading(isLoading: Boolean) {
        if(isLoading) {
            binding.progressBar.visibility = View.VISIBLE
            binding.btnNext.visibility = View.GONE
            binding.imageProfile.isEnabled = false
            binding.textNameLayout.isEnabled = false
            binding.textAboutLayout.isEnabled = false
        } else {
            binding.progressBar.visibility = View.GONE
            binding.btnNext.visibility = View.VISIBLE
            binding.imageProfile.isEnabled = true
            binding.textNameLayout.isEnabled = true
            binding.textAboutLayout.isEnabled = true
        }
    }
}