package com.example.walkchat.activities;

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.objects.Constants
import kotlinx.coroutines.launch

open class BaseActivity: AppCompatActivity() {
    private lateinit var fireStoreRepo: FireStoreRepo
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fireStoreRepo = FireStoreRepo(this)
    }

    override fun onPause() {
        super.onPause()
        changeAvailability(0)
    }

    override fun onResume() {
        super.onResume()
        changeAvailability(1)
    }


    private fun changeAvailability(availability: Int) {
        lifecycleScope.launch {
            fireStoreRepo.updateUserByKey(Constants.KEY_AVAILABILITY, availability)
        }
    }
}
