package com.example.walkchat.activities

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.walkchat.R
import com.example.walkchat.adapters.ViewPageAdapter
import com.example.walkchat.databinding.ActivityMainBinding
import com.example.walkchat.databinding.CustomLogOutBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.helper.GalleryHelper
import com.example.walkchat.objects.Constants
import com.example.walkchat.objects.PreferenceManager
import com.example.walkchat.objects.Utils.changeActivity
import com.example.walkchat.objects.Utils.showToast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewPageAdapter: ViewPageAdapter
    private lateinit var preferenceManager: PreferenceManager
    private lateinit var fireStoreRepo: FireStoreRepo
    private lateinit var galleryHelper: GalleryHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
        loadDetails()
        attachViewPager()
        setListener()
        setToken()

    }

    private fun init() {
        preferenceManager = PreferenceManager(this)
        viewPageAdapter = ViewPageAdapter(supportFragmentManager, lifecycle)
        fireStoreRepo = FireStoreRepo(this)
        galleryHelper = GalleryHelper(this)
    }

    private fun loadDetails() {
        binding.textName.text = preferenceManager.getString(Constants.KEY_NAME)
        Glide.with(this).load(preferenceManager.getString(Constants.KEY_IMAGE)).into(binding.imageProfile)
    }

    private fun attachViewPager() {
        binding.viewPager2.adapter = viewPageAdapter

        binding.viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                binding.bottomNavbar.menu.getItem(position).isChecked = true

                when (position) {
                    0 -> {
                        binding.fabNewChat.show()
                        binding.fabNewChat.setImageResource(R.drawable.round_add_24)
                        binding.fabNewChat.setOnClickListener {
                            changeActivity(this@MainActivity, Contacts())
                            overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                        }
                    }

                    1 -> {
                        binding.fabNewChat.show()
                        binding.fabNewChat.setImageResource(R.drawable.baseline_photo_camera_24)
                        binding.fabNewChat.setOnClickListener {
                            galleryHelper.openGallery()
                        }
                    }

                    2 -> {
                        binding.fabNewChat.hide()
                    }
                }
            }
        })
    }

    private fun setListener() {
        binding.imageSignOut.setOnClickListener {
            showLogoutConfirmationDialog()
        }

        binding.bottomNavbar.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.bottom_navigation_menu_chats -> binding.viewPager2.setCurrentItem(0, false)
                R.id.bottom_navigation_menu_status -> binding.viewPager2.setCurrentItem(1, false)
                R.id.bottom_navigation_menu_profile -> binding.viewPager2.setCurrentItem(2, false)
            }
            true
        }

    }

    private fun setToken() {
        FirebaseMessaging.getInstance().token.addOnSuccessListener(this::updateToken)
    }

    private fun updateToken(token: String) {
        preferenceManager.putString(Constants.KEY_FCM_TOKEN, token)

        lifecycleScope.launch {
            fireStoreRepo.updateUserByKey(Constants.KEY_FCM_TOKEN, token)
        }
    }

    override fun startActivity(intent: Intent?) {
        super.startActivity(intent)
        overridePendingTransition(R.anim.fade_out, R.anim.fade_in)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if(requestCode == 124) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                galleryHelper.openGallery()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun showLogoutConfirmationDialog() {

        val dialogView = CustomLogOutBinding.inflate(layoutInflater).root
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        //setting bg -> transparent
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        //changing text of buttons
        val yes = dialogView.findViewById<Button>(R.id.btnOk)
        val no = dialogView.findViewById<Button>(R.id.btnIgnore)


        dialogView.findViewById<TextView>(R.id.dialog_message).text =
            getString(R.string.are_you_sure_do_you_want_to_logout_from_this_device)

        yes.text = getString(R.string.yes)
        no.text = getString(R.string.no)


        // Set button click listeners
        yes.setOnClickListener {

            lifecycleScope.launch {

                val isTokenDeleted = fireStoreRepo.deleteUserDataByKey(Constants.KEY_FCM_TOKEN)

                if(isTokenDeleted) {
                    preferenceManager.clear()
                    showToast(this@MainActivity, "signing out")
                    FirebaseAuth.getInstance().signOut()
                    changeActivity(this@MainActivity, MobileAuthentication())
                    finish()
                    dialog.dismiss()
                } else {
                    Toast.makeText(this@MainActivity, "Something Went wrong Please try again", Toast.LENGTH_SHORT).show()
                }
            }
        }

        no.setOnClickListener {
            // do nothing
            dialog.dismiss()
        }

        // Show the dialog
        dialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val selectedImageUri = galleryHelper.handleActivityResult(requestCode, resultCode, data)
        if (selectedImageUri != null) {
            galleryHelper.passMediaUriToNextActivity(this, selectedImageUri)
        }
    }

    override fun onBackPressed() {
        if(binding.viewPager2.currentItem != 0) {
            binding.viewPager2.currentItem = 0
        } else {
            super.onBackPressed()
        }

    }


}