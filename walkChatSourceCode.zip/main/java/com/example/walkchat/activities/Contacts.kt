package com.example.walkchat.activities

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.walkchat.R
import com.example.walkchat.adapters.ContactsAdapter
import com.example.walkchat.databinding.ActivityContactsBinding
import com.example.walkchat.firebase.FireStoreRepo
import com.example.walkchat.models.Contact
import com.example.walkchat.models.User
import com.example.walkchat.objects.Utils
import com.example.walkchat.objects.Utils.showToast
import com.example.walkchat.viewmodels.ContactViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Contacts : BaseActivity() {
    private lateinit var binding: ActivityContactsBinding
    private lateinit var contactViewModel: ContactViewModel
    private lateinit var fireStoreRepo: FireStoreRepo
    private var userContacts: MutableList<Contact> = mutableListOf()

    companion object {
        private const val REQUEST_READ_CONTACTS = 1
        private var comparatorCalled = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
        setClickListeners()
        fetchContacts()
    }

    private fun init() {
        contactViewModel = ViewModelProvider(this)[ContactViewModel::class.java]
        fireStoreRepo = FireStoreRepo(this)
        binding.contactsRecyclerView.adapter = ContactsAdapter(this, userContacts)
        comparatorCalled = true
    }

    private fun setClickListeners() {
        binding.imageBack.setOnClickListener {
            onBackPressed()
        }
    }

    private fun fetchContacts() {
        if(checkPermissions()) {
            handleContacts()
        } else {
            requestPermission()
        }
    }

    private fun checkPermissions():Boolean {
        return ContextCompat
            .checkSelfPermission(
                this,
                android.Manifest.permission.READ_CONTACTS) ==
                PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        ActivityCompat
            .requestPermissions(
                this,
                arrayOf(android.Manifest.permission.READ_CONTACTS),
                REQUEST_READ_CONTACTS
            )
    }

    private fun handleContacts() {
        if (checkPermissions()) {
            // Observe the contacts LiveData
            contactViewModel.contacts.observe(this@Contacts) { roomContacts ->
                    CoroutineScope(Dispatchers.Main).launch {
                        isLoading(true)
                        if (roomContacts.isNullOrEmpty()) {
                            // Room database is empty, insert all device contacts
                            val deviceContacts = withContext(Dispatchers.Default) { Utils.fetchDeviceContacts(this@Contacts) }
                            async { contactViewModel.insertContacts(deviceContacts) }.await()
                            // Wait for insertion to complete before fetching Firebase users
                            async { fetchFirebaseUsersAndCompare(deviceContacts) }.await()

                        } else {

                            observeRoomContacts()
                            isLoading(false)
                            // Room database has existing contacts, compare with current device contacts
                            val currentDeviceContacts = withContext(Dispatchers.Default) { Utils.fetchDeviceContacts(this@Contacts) }
                            val (existingContacts, newContacts) = currentDeviceContacts.partition { deviceContact ->
                                roomContacts.any { it.contactNo == deviceContact.contactNo }
                            }

                            // Insert new contacts into Room database
                           async { contactViewModel.insertContacts(newContacts) }.await()
                            // Update existing contacts in Room database
                           async { fetchFirebaseUsersAndCompare(currentDeviceContacts)}.await()

                        }

                    // Observe room contacts after fetchAndCompareContacts is completed

                }
            }
        } else {
            requestPermission()
        }

    }

    private suspend fun fetchFirebaseUsersAndCompare(roomContacts: List<Contact>) {
        // Fetch all users from Firebase

        CoroutineScope(Dispatchers.Main).launch {

            val modifiedRoomContacts = mutableListOf<Contact>()

            fireStoreRepo.getAllUsers().onSuccess { firebaseUsers ->

                roomContacts.forEach { contact ->
                    val firebaseUser = firebaseUsers.find { it.mobileNo == contact.contactNo }

                    if (firebaseUser != null) {
                        contact.apply {
                            contactId = firebaseUser.userId
                            contactAbout = firebaseUser.about
                            contactImage = firebaseUser.image
                            inDB = true
                        }

                        modifiedRoomContacts.add(contact)

                        Log.d("contactsUpdatedData", contact.toString())
                    }
                }

                Log.d("contactsModified", modifiedRoomContacts.toString())

                async { contactViewModel.updateContacts(modifiedRoomContacts) }.await()
                observeRoomContacts()
                isLoading(false)
            }
        }

    }

    // Function to observe Room contacts and update UI
    private fun observeRoomContacts() {
        contactViewModel.contacts.observe(this) { contacts ->
            val (availableContacts, unAvailableContacts) = contacts.partition { it.inDB }
            // Pass the available and unavailable contacts to the adapter for UI update
            Log.d("modifiesContacts", availableContacts.toString())
            updateUIWithContacts(availableContacts, unAvailableContacts)
        }
    }

    // Function to update UI with contacts
    private fun updateUIWithContacts(availableContacts: List<Contact>, unAvailableContacts: List<Contact>) {
        isLoading(true)
        userContacts.clear()
        userContacts.addAll(availableContacts + unAvailableContacts)
        binding.contactsRecyclerView.adapter?.notifyDataSetChanged()
        isLoading(false)
    }

    private fun isLoading(isLoading: Boolean) {
        if(isLoading) {
            binding.progressBar.visibility = View.VISIBLE
            binding.contactsRecyclerView.visibility = View.GONE
        } else {
            binding.progressBar.visibility = View.GONE
            binding.contactsRecyclerView.visibility = View.VISIBLE
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_READ_CONTACTS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                handleContacts()
            } else {
                showToast(this, "Permissions Denied")
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }

}