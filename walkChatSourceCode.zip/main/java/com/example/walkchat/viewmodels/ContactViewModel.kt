package com.example.walkchat.viewmodels

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.bumptech.glide.Glide.init
import com.example.walkchat.models.Contact
import com.example.walkchat.objects.AppDatabase
import com.example.walkchat.objects.ContactRepository
import kotlinx.coroutines.launch

class ContactViewModel(application: Application): AndroidViewModel(application) {
    private val repository: ContactRepository

    val contacts: LiveData<List<Contact>>
    val contactIds: LiveData<List<String>>


    init {
        repository = ContactRepository(
            AppDatabase
                .getInstance(application)
                .contactDao()
        )

        contacts = repository.contacts()
        contactIds = repository.getAllContactIds()
    }

    fun contactById(contactId: String): LiveData<Contact> {
      return repository.contact(contactId)
    }

    fun insertContacts(contacts: List<Contact>) = viewModelScope.launch {
        repository.insertContacts(contacts)
    }

    fun updateContacts(contacts: List<Contact>) = viewModelScope.launch {
        Log.d("contactsViewModel", contacts.toString())
        repository.updateContacts(contacts)
    }


    fun updateContactStatus(phoneNumber: String) = viewModelScope.launch {
            repository.updateContactStatus(phoneNumber)
        }






}